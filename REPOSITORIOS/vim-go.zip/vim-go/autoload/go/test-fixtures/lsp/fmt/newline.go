package main

import "fmt"
func main() {
	fmt.Println("vim-go")
}
