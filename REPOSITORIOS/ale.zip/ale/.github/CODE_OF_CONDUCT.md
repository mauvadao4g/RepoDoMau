Codes of conduct are totally unnecessary and dumb.

Just don't be a jerk and have fun.
