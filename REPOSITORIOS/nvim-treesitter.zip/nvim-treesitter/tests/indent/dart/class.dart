void main() {
}

class Test {
  List<String> get progress => [
        '0',
      ];
}
