fn foo() {
    let a = "hello
world";

    let b = "hello\
        world";

    let c = r#"
        hello
        world
    "#;
}
