switch (variable) {
  case 'case1':
    foo();
    break;

  default:
    bar();
}
