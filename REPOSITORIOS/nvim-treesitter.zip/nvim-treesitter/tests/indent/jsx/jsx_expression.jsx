export default function Home() {
  return (
    <>
      <Button
        style={
        }
      >
      </Button>
      <Button
        style={{
          color: 'blue',
        }}
      />
    </>
  )
}
