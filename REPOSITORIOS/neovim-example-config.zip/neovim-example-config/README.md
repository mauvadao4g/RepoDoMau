# neovim-example-config
una configuracion de neovim para trabajar con PHP

# Video de youtube donde la configuro desde cero [link](https://youtu.be/NczzKS9AdRA)
