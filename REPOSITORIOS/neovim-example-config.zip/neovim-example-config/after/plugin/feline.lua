require('feline').setup()

require('feline').winbar.setup()
