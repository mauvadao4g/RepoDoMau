const a = () => { return 2; };
