# Snippets

### Install
vim 8+ manages packages all on its own
```
$ mkdir -p ~/.vim/pack/vendor/start
$ cd ~/.vim/pack/vendor/start
$ git clone https://github.com/akinalibeer/vim-snipmate.git
$ cd vim-snipmate
$ git submodule add https://github.com/estefanionsantos/snippets.git
```

Forked from: [@msanders/snipmate.vim](https://github.com/msanders/snipmate.vim) | [Contributors](../../graphs/contributors)
